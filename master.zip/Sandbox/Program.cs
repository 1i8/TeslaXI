﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Text;
using TheLeftExit.Memory;
using TheLeftExit.Memory.Queries;

/* - Get the resulting pointer
 * - Get intermediate pointers
 * - Get intermediate offsets
 * - 
 * 
 * 
 */

namespace Sandbox
{
    class Program
    {
        static void Main(string[] args)
        {
            Process gt = Process.GetProcessesByName("Growtopia").Single();
            IntPtr handle = gt.Handle;
            Int64 baseAddress = (Int64)gt.MainModule.BaseAddress;


            PointerQuery AppQuery = new RTTIQuery() { ClassName = "App", Range = 0x1200000 };
            PointerQuery GameLogicComponentQuery = new RTTIQuery() { ClassName = "GameLogicComponent", Range = 0x1000 };
            PointerQuery NetAvatarQuery = new RTTIQuery() { ClassName = "NetAvatar", Range = 0x1000 };
            PointerQuery WorldQuery = new RTTIQuery() { ClassName = "World", Range = 0x1000 };

            PointerQueryResult App = AppQuery.Run(handle, baseAddress);
            PointerQueryResult GameLogicComponent = GameLogicComponentQuery.Run(handle, App.Target);
            PointerQueryResult NetAvatar = NetAvatarQuery.Run(handle, GameLogicComponent.Target);
            PointerQueryResult World = WorldQuery.Run(handle, GameLogicComponent.Target);

            Console.WriteLine($"NetAvatar is at {NetAvatar.Target.ToString("X")}");
            // NetAvatar is at 19AED535680

            StringBuilder NetAvatarLocation = new("Growtopia.exe");
            foreach (var r in new PointerQueryResult[] { App, GameLogicComponent, World })
                NetAvatarLocation.Append("+" + r.Offset.ToString("X"));

            Console.WriteLine($"World can found at {NetAvatarLocation}");
            // World can found at Growtopia.exe+9FC900+AB0+108
        }
    }
}
