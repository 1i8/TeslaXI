﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using TheLeftExit.Memory;
using TheLeftExit.Memory.RTTI;

namespace TheLeftExit.Memory.Queries
{
    /// <summary>
    /// Container for pointer query result (contains both resulting address, and offset for future use).
    /// </summary>
    public struct PointerQueryResult
    {
        public Int64 Target;
        public Int32 Offset;
        public static PointerQueryResult None = new();
    }

    /// <summary>
    /// Base class for any memory queries.
    /// </summary>
    public abstract class PointerQuery
    {
        public abstract PointerQueryResult Run(IntPtr handle, Int64 source);
    }

    public enum Kind
    {
        /// <summary>
        /// Check structures located in specified range.
        /// </summary>
        Value,
        /// <summary>
        /// Check structures, pointers to which are located in specified range.
        /// </summary>
        Reference
    }
}
