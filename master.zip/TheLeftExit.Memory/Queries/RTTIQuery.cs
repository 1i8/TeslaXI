﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using TheLeftExit.Memory;
using TheLeftExit.Memory.RTTI;

namespace TheLeftExit.Memory.Queries
{
    /// <summary>
    /// Query that searches an address range for structures with a specified RTTI class name.
    /// </summary>
    public class RTTIQuery : PointerQuery
    {
        /// <summary>
        /// Class name to look for.
        /// </summary>
        public string ClassName { get; init; }
        /// <summary>
        /// Maximum offset to search in.
        /// </summary>
        public Int32 Range { get; init; }
        /// <summary>
        /// First offset to check.
        /// </summary>
        public Int32 Default { get; init; } = 0;
        /// <summary>
        /// Whether the range contains the structure itself, or a pointer to it.<br/>Default: Kind.Reference.
        /// </summary>
        public Kind ScanBy { get; init; } = Kind.Reference;
        /// <summary>
        /// When scanning by reference - whether to return address of reference or address of value. Default: Kind.Value.
        /// </summary>
        public Kind Return { get; init; } = Kind.Value;
        /// <summary>
        /// Increase performance by ignoring secondary class names.<br/>Default: true.
        /// </summary>
        public bool FirstNameOnly { get; init; } = true;
        /// <summary>
        /// Whether 32-bit RTTI functions should be used.<br/>Default: false.
        /// </summary>
        public bool Is32Bit { get; init; } = false;


        public override PointerQueryResult Run(IntPtr handle, Int64 source)
        {
            // We're building a function on the fly instead of using a bunch of IF statements!
            Func<Int64, Int64> GetStructure = ScanBy == Kind.Value ? (x => x) : (x => handle.ReadInt64(x));
            Func<Int64, bool> CheckClassName = Is32Bit ?
                (FirstNameOnly ? (x => handle.GetRTTIClassName32(x) == ClassName) : (x => handle.GetRTTIClassNames32(x)?.Contains(ClassName) ?? false)) :
                (FirstNameOnly ? (x => handle.GetRTTIClassName64(x) == ClassName) : (x => handle.GetRTTIClassNames64(x)?.Contains(ClassName) ?? false));
            Int32 step = Is32Bit ? 4 : 8;

            // Checking cached offset if provided.
            Int64 defaultAddress = source + Default;
            Int64 defaultTarget = GetStructure(source + Default);
            if (CheckClassName(defaultTarget))
                return new PointerQueryResult()
                {
                    Target = Return == Kind.Reference ? defaultAddress : defaultTarget,
                    Offset = Default
                };

            // Scanning given range.
            for (Int64 i = source; i <= source + Range; i += step)
            {
                Int64 addr = GetStructure(i);
                if (CheckClassName(addr))
                    return new PointerQueryResult()
                    {
                        Target = Return == Kind.Reference ? i : addr,
                        Offset = (Int32)(i - source)
                    };
            }

            // Uh oh.
            return PointerQueryResult.None;
        }
    }
}
